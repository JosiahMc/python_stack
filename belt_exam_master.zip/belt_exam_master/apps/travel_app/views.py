# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
from .models import Plans
from django import forms

# Create your views here.

def destination(request):
	print "landing route is working"
	return render(request, "destination.html")

def addplan(request):
	print "add plan route is working"
	return render(request, "addplan.html")
    	
    
def create_plan(request):
	if request.method == 'POST':
		print request.POST
	print "hit create plan in views / post route"
	plans = Plans()
	plans.destination = request.POST['destination']
	plans.description = request.POST['description']
	plans.start_date = request.POST['start_date']
	plans.end_date = request.POST['end_date']
	# plans.created_by = request.POST['first_name']
	plans.save()
	return render(request, "destination.html")
