# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from ..login_app.models import Users
from django.db import models
# from login_app.users import Class1

# from .CreateTable import users

#IF TIME TO VALIDATE
# class plan_manager(models.Manager):
#     def create_validator(self, postData):
#         errors = {}
#         if len(postData['destination']) < 1:
#             errors["destination"] = "Cannot be empty!"
#         if len(postData['description']) < 1:
#             errors["description"] = "Cannot be empty!"
#         return errors



class Plans(models.Model):
    destination = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    start_date = models.DateTimeField(auto_now_add=True)
    end_date = models.DateTimeField(auto_now=True)
    # created_by = models.ForeignKey(Users, related_name="created_trips")
    # joined_users = models.ManyToManyField(Users, related_name="joined_trips")
    
    
    #RUNNING OUT OF TIME SCRAPPED THIS TOO :(
    # ERRORS: travel_app.plans.planned_by: (fields.E300) Field defines a relation with model 'first_name', which is either not installed, or is abstract. travel_app.plans.planned_by: (fields.E307) The field travel_app.plans.planned_by was declared with a lazy reference to 'travel_app.first_name', but app 'travel_app' doesn't provide model 'first_name'.
    # planned_by = models.ForeignKey('first_name', on_delete=models.CASCADE, related_name="user_plans")



    #RUNNINNG OUT OF TIME Keep getting "NameError: name 'Users' i
    # s not defined"
    # userplans = models.ManyToManyField(Users)
    
    
    #IF TIME PASS plans here to validate
    # objects = plan_manager()





# # Many to many relationship between users and plans
# class trips(models.Model):
#     # One user can have many plans
#     user = models.ForeignKey('user', on_delete=models.CASCADE, related_name="user_plans")
#     # One plan can have many users
#     users = models.ForeignKey(plans, on_delete=models.CASCADE, related_name="planned_by_users")
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
    

    