from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^destination', views.destination),
    url(r'^addplan', views.addplan),
    url(r'^create_plan', views.create_plan),
]